var express = require('express');
var request = require('request');
var app = express();

var url = 'https://<%USER%>:<%PASS%>@api.infojobs.net/api/1/offer';
var clientID = 'ce6a08f744ab4d1db3761a3c8f2dc1c0';
var clientSecret = 'e8hFf5kmoJ1PYQmq2IoKri1l7xQVFwvhoaR8A30hz5x5U+yWI7';

app.get('/offers-method-one', function (req, res) {

	var urlOffers1 = url.replace('<%USER%>', clientID);
	urlOffers1 = urlOffers1.replace('<%PASS%>', clientSecret);
	console.log (urlOffers1)

	request( { url : urlOffers1 }, function (error, response, body) {
				res.json(response);
	});

});

app.get('/offers-method-two', function (req, res) {

	var urlOffers2 = url.replace('<%USER%>:<%PASS%>@', '');
	var auth = "Basic " + new Buffer(clientID + ":" + clientSecret).toString("base64");
	console.log (urlOffers2)

	request( {
		url : urlOffers2,
		headers : { "Authorization" : auth }
	}, function (error, response, body) {
				res.json(response);
	});

});

app.listen(3000);